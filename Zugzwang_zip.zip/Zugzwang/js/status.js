import { getBoardStateHash } from './utils.js';
import { playerPieces, aiPieces } from './pieces.js';
import { inCheck } from './move.js';
import { attemptMove } from './move.js';

export let positionHistory = {};

export function resetStatus() {
  positionHistory = {};
}

export function updateStatus(turn) {
  const statusDiv = document.getElementById('status');

  if (!playerPieces.knight && !aiPieces.knight) {
    statusDiv.textContent = '🟨 Draw! Both knights are gone.';
    return 'draw';
  }
  if (!inCheck(true) && !hasLegalMoves(true)) {
    statusDiv.textContent = '🟨 Draw! White is stalemated.';
    return 'draw';
  }
  if (!inCheck(false) && !hasLegalMoves(false)) {
    statusDiv.textContent = '🟨 Draw! Black is stalemated.';
    return 'draw';
  }

  const hash = getBoardStateHash();
  positionHistory[hash] = (positionHistory[hash] || 0) + 1;
  if (positionHistory[hash] >= 3) {
    statusDiv.textContent = '🟨 Draw by repetition.';
    return 'draw';
  }

  statusDiv.textContent = turn === 'player' ? 'White’s move...' : 'Black’s move...';
  return 'continue';
}

export function updateLog(moveLog) {
  const logList = document.getElementById('move-log');
  logList.innerHTML = '';
  for (let i = 0; i < moveLog.length; i += 2) {
    const p = moveLog[i] || '';
    const a = moveLog[i + 1] || '';
    const li = document.createElement('li');
    li.textContent = `${i / 2 + 1}. ${p} ${a}`;
    logList.appendChild(li);
  }
}

function hasLegalMoves(isPlayer) {
  const team = isPlayer ? playerPieces : aiPieces;
  for (const [piece, [x, y]] of Object.entries(team)) {
    for (let dx = -2; dx <= 2; dx++) {
      for (let dy = -2; dy <= 2; dy++) {
        if (dx === 0 && dy === 0) continue;
        const nx = x + dx;
        const ny = y + dy;
        if (attemptMove(piece, x, y, nx, ny, isPlayer, true)) return true;
      }
    }
  }
  return false;
}
