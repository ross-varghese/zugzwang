import { board } from './board.js';
import { playerPieces, aiPieces } from './pieces.js';

export function getBoardStateHash() {
  return board.flat().join('') +
         '|' + JSON.stringify(playerPieces) +
         '|' + JSON.stringify(aiPieces);
}
