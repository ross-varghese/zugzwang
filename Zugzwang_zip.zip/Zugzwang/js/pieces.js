export const PIECES = {
  player: { king: '♔', knight: '♘' },
  ai:     { king: '♚', knight: '♞' }
};

export let playerPieces = {};
export let aiPieces = {};

export function initializePieces() {
  playerPieces = { king: [4, 2], knight: [4, 3] };
  aiPieces     = { king: [0, 2], knight: [0, 1] };
}
