import { PIECES, playerPieces, aiPieces } from './pieces.js';
import { board } from './board.js';
import { moveLog, turn } from './game.js'; // ✅ Import moveLog and turn

const FILES = ['a', 'b', 'c', 'd', 'e'];
const RANKS = ['5', '4', '3', '2', '1'];

export function inCheck(isPlayer) {
  const king = isPlayer ? playerPieces.king : aiPieces.king;
  const opponent = isPlayer ? aiPieces : playerPieces;
  if (!king) return false;
  return Object.values(opponent).some(([x, y]) => {
    const dx = Math.abs(x - king[0]);
    const dy = Math.abs(y - king[1]);
    const piece = board[x]?.[y];
    return piece &&
      piece === (isPlayer ? PIECES.ai.knight : PIECES.player.knight) &&
      ((dx === 2 && dy === 1) || (dx === 1 && dy === 2));
  });
}

export function attemptMove(piece, x, y, nx, ny, isPlayer, testOnly = false) {
  if (nx < 0 || ny < 0 || nx >= 5 || ny >= 5) return false;
  const team = isPlayer ? playerPieces : aiPieces;
  const opponent = isPlayer ? aiPieces : playerPieces;

  if (board[nx][ny] !== '.' &&
      Object.values(PIECES[isPlayer ? 'player' : 'ai']).includes(board[nx][ny])) return false;

  const dx = Math.abs(nx - x);
  const dy = Math.abs(ny - y);
  if (piece === 'knight' && !((dx === 2 && dy === 1) || (dx === 1 && dy === 2))) return false;
  if (piece === 'king' && (dx > 1 || dy > 1)) return false;

  const oppKing = opponent.king;
  if (piece === 'king' && oppKing &&
      Math.abs(oppKing[0] - nx) <= 1 &&
      Math.abs(oppKing[1] - ny) <= 1) return false;

  const original = [...team[piece]];
  const captured = Object.entries(opponent).find(([, pos]) => pos[0] === nx && pos[1] === ny);
  const capturedKey = captured?.[0];
  const capturedVal = captured?.[1];

  board[x][y] = '.';
  board[nx][ny] = PIECES[isPlayer ? 'player' : 'ai'][piece];
  team[piece] = [nx, ny];
  if (capturedKey) delete opponent[capturedKey];

  const danger = inCheck(isPlayer);

  if (testOnly || danger) {
    board[nx][ny] = capturedVal ? PIECES[isPlayer ? 'ai' : 'player'][capturedKey] : '.';
    board[x][y] = PIECES[isPlayer ? 'player' : 'ai'][piece];
    team[piece] = original;
    if (capturedKey) opponent[capturedKey] = capturedVal;
    return !danger;
  }

  // ✅ Log the move
  moveLog.push(`${turn === 'player' ? '' : '... '}${piece[0].toUpperCase()}${FILES[ny]}${RANKS[nx]}`);

  return true;
}
