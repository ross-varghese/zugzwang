//import { PIECES, playerPieces, aiPieces, initializePieces } from './pieces.js';
import {initializePieces } from './pieces.js';
import { setupBoard, renderBoard } from './board.js';
import { botTurn } from './logic.js';
import { updateStatus, updateLog, resetStatus } from './status.js';

export let moveLog = [];
export let turn = 'player'; // ✅ White always starts

export function restartGame() {
  initializePieces();
  setupBoard();
  moveLog = [];
  resetStatus();
  turn = 'player';
  renderBoard();
  updateLog(moveLog);
  document.getElementById('status').textContent = 'White starts the match!';
}

export function nextTurn() {
  if (turn === 'none') return;
  const isPlayer = turn === 'player';

  console.log(`🔄 Turn: ${isPlayer ? 'White (player)' : 'Black (ai)'}`);

  const moved = botTurn(isPlayer); // ✅ Both bots play

  setupBoard();           // Place pieces after move
  renderBoard();
  updateLog(moveLog);     // Update sidebar move log

  const result = updateStatus(turn);
  if (result === 'draw') {
    turn = 'none';
    setTimeout(() => {
        restartGame();
        setTimeout(nextTurn, 1500);
    }, 1500);
  }
 else {
    turn = isPlayer ? 'ai' : 'player'; // Alternate turns
    setTimeout(nextTurn, 1500);        // Queue next turn
  }
}
