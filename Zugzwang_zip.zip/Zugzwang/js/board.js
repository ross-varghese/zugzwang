import { PIECES, playerPieces, aiPieces } from './pieces.js';

export let board = [];

export function setupBoard() {
  board = Array.from({ length: 5 }, () => Array(5).fill('.'));
  for (const [p, [x, y]] of Object.entries(playerPieces)) {
    board[x][y] = PIECES.player[p];
  }
  for (const [p, [x, y]] of Object.entries(aiPieces)) {
    board[x][y] = PIECES.ai[p];
  }
}

export function renderBoard() {
  const boardDiv = document.getElementById('board');
  boardDiv.innerHTML = '';
  for (let x = 0; x < 5; x++) {
    for (let y = 0; y < 5; y++) {
      const square = document.createElement('div');
      square.className = 'square ' + ((x + y) % 2 === 0 ? 'light' : 'dark');
      square.textContent = board[x][y] !== '.' ? board[x][y] : '';
      boardDiv.appendChild(square);
    }
  }
}
