import { PIECES, playerPieces, aiPieces } from './pieces.js';
import { board } from './board.js';
import { inCheck, attemptMove } from './move.js';

function getThreatenedSquares(opponentTeam) {
  const threatened = new Set();
  for (const [piece, [x, y]] of Object.entries(opponentTeam)) {
    const deltas = piece === 'knight'
      ? [[2,1],[1,2],[-1,2],[-2,1],[-2,-1],[-1,-2],[1,-2],[2,-1]]
      : [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]];

    for (const [dx, dy] of deltas) {
      const nx = x + dx;
      const ny = y + dy;
      if (nx >= 0 && nx < 5 && ny >= 0 && ny < 5) {
        threatened.add(`${nx},${ny}`);
      }
    }
  }
  return threatened;
}

export function botTurn(isPlayer) {
  const team = isPlayer ? playerPieces : aiPieces;
  const opponentTeam = isPlayer ? aiPieces : playerPieces;
  const opponentSymbols = Object.values(PIECES[isPlayer ? 'ai' : 'player']);
  const threatenedSquares = getThreatenedSquares(opponentTeam);
  const allMoves = [];

  console.log("🔍 Bot Turn:", isPlayer ? "White" : "Black");

  for (const [piece, [x, y]] of Object.entries(team)) {
    for (let dx = -2; dx <= 2; dx++) {
      for (let dy = -2; dy <= 2; dy++) {
        const nx = x + dx;
        const ny = y + dy;
        if ((dx === 0 && dy === 0)) continue;
        if (!attemptMove(piece, x, y, nx, ny, isPlayer, true)) continue;

        const move = { piece, x, y, nx, ny };
        const target = board[nx]?.[ny];
        const destKey = `${nx},${ny}`;

        const captures = opponentSymbols.includes(target);
        const checks = (() => {
          // Simulate move
          const tmp = board[nx][ny];
          const original = [...team[piece]];

          board[x][y] = '.';
          board[nx][ny] = PIECES[isPlayer ? 'player' : 'ai'][piece];
          team[piece] = [nx, ny];

          const causesCheck = inCheck(!isPlayer);

          board[nx][ny] = tmp;
          board[x][y] = PIECES[isPlayer ? 'player' : 'ai'][piece];
          team[piece] = original;

          return causesCheck;
        })();

        if (!captures && threatenedSquares.has(destKey)) continue; // Don't enter danger unless attacking

        move.priority = (captures ? 3 : 0) + (checks ? 2 : 0) + 1;
        allMoves.push(move);
      }
    }
  }

  if (allMoves.length === 0) {
    console.warn("⚠️ No safe moves found for", isPlayer ? "White" : "Black");
    return false;
  }

  allMoves.sort((a, b) => b.priority - a.priority || Math.random() - 0.5);

  for (const move of allMoves) {
    const success = attemptMove(move.piece, move.x, move.y, move.nx, move.ny, isPlayer);
    if (success) {
      console.log("✅ Executed move:", move);
      return true;
    }
  }

  console.warn("⛔ All filtered moves failed during execution.");
  return false;
}
